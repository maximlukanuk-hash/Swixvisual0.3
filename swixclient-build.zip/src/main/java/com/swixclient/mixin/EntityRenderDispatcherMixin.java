package com.swixclient.mixin;

import com.swixclient.module.Chams;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import org.lwjgl.opengl.GL11;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Chams: while an entity is being drawn, a huge negative polygon offset pulls its depth
 * towards the camera, so the model passes the depth test even behind blocks.
 * The batched vertices are flushed right before and right after the entity,
 * so the offset affects only this one entity.
 */
@Mixin(EntityRenderDispatcher.class)
public class EntityRenderDispatcherMixin {
    private static final String RENDER =
            "render(Lnet/minecraft/entity/Entity;DDDFLnet/minecraft/client/util/math/MatrixStack;"
                    + "Lnet/minecraft/client/render/VertexConsumerProvider;I)V";

    private static boolean swixclient$chamsActive;

    @Inject(method = RENDER, at = @At("HEAD"))
    private void swixclient$chamsBegin(Entity entity, double x, double y, double z, float tickDelta,
                                       MatrixStack matrices, VertexConsumerProvider vertexConsumers,
                                       int light, CallbackInfo ci) {
        if (swixclient$chamsActive || !Chams.shouldRender(entity)) return;
        if (!(vertexConsumers instanceof VertexConsumerProvider.Immediate immediate)) return;

        immediate.draw(); // flush what was queued before, without the offset
        GL11.glEnable(GL11.GL_POLYGON_OFFSET_FILL);
        GL11.glPolygonOffset(1.0f, -1100000.0f);
        swixclient$chamsActive = true;
    }

    @Inject(method = RENDER, at = @At("RETURN"))
    private void swixclient$chamsEnd(Entity entity, double x, double y, double z, float tickDelta,
                                     MatrixStack matrices, VertexConsumerProvider vertexConsumers,
                                     int light, CallbackInfo ci) {
        if (!swixclient$chamsActive) return;
        swixclient$chamsActive = false;

        if (vertexConsumers instanceof VertexConsumerProvider.Immediate immediate) {
            immediate.draw(); // draw this entity with the offset
        }
        GL11.glPolygonOffset(0.0f, 0.0f);
        GL11.glDisable(GL11.GL_POLYGON_OFFSET_FILL);
    }
}
