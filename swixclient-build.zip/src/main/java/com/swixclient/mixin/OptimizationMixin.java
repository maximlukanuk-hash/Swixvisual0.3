package com.swixclient.mixin;

import com.swixclient.module.Optimization;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Optimization: far entities are not rendered at all. */
@Mixin(EntityRenderDispatcher.class)
public class OptimizationMixin {
    @Inject(method = "shouldRender", at = @At("HEAD"), cancellable = true)
    private void swixclient$cull(Entity entity, Frustum frustum, double x, double y, double z,
                                 CallbackInfoReturnable<Boolean> cir) {
        if (Optimization.shouldCull(entity)) cir.setReturnValue(false);
    }
}
