package com.swixclient.module;

import com.swixclient.mixin.GameRendererAccessor;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/**
 * Saturation: более насыщенные цвета всей картинки (экранный пост-эффект, виден только тебе).
 * Сила 1 = чуть ярче, 2 = заметно, 3 = очень сочно.
 * Если эффект не включился, модуль сам выключится и напишет об этом в чат.
 */
public class Saturation extends Module {
    private final NumberSetting level = add(new NumberSetting("Сила (1-3)", 2, 1, 3, 1));
    private int applied = -1;

    public Saturation() {
        super("Saturation", "Более насыщенные цвета", Category.RENDER);
    }

    @Override
    protected void onEnable() {
        applied = -1;
    }

    @Override
    protected void onDisable() {
        applied = -1;
        try {
            if (mc().gameRenderer != null) mc().gameRenderer.disablePostProcessor();
        } catch (Throwable ignored) {
        }
    }

    @Override
    public void onTick() {
        int lv = level.getInt();
        if (lv == applied) return;
        applied = lv;
        try {
            ((GameRendererAccessor) mc().gameRenderer)
                    .swixclient$setPostProcessor(Identifier.of("swixclient", "saturation_" + lv));
        } catch (Throwable t) {
            if (mc().player != null) {
                mc().player.sendMessage(Text.literal("[SwixClient] Saturation не заработал в этой версии: " + t.getClass().getSimpleName()), false);
            }
            setEnabled(false);
        }
    }
}
