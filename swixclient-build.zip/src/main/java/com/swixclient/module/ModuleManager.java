package com.swixclient.module;

import com.swixclient.gui.ClickGuiScreen;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class ModuleManager {
    private static final String CATEGORY = "key.categories.swixclient";

    private final List<Module> modules = new ArrayList<>();
    private final Map<Module, KeyBinding> moduleKeys = new LinkedHashMap<>();
    private KeyBinding guiKey;
    private KeyBinding hudKey;
    private boolean hudVisible = true;
    private boolean openGuiRequested;

    public void init() {
        register(new Fullbright(), "key.swixclient.fullbright", GLFW.GLFW_KEY_G);
        register(new Chams(), "key.swixclient.chams", GLFW.GLFW_KEY_R);
        register(new AirStuck(), "key.swixclient.airstuck", GLFW.GLFW_KEY_X);
        register(new TargetEsp(), "key.swixclient.targetesp", GLFW.GLFW_KEY_J);
        register(new AutoSprint(), "key.swixclient.autosprint", GLFW.GLFW_KEY_V);
        register(new Atmosphere(), "key.swixclient.atmosphere", GLFW.GLFW_KEY_N);
        register(new Optimization(), "key.swixclient.optimization", GLFW.GLFW_KEY_P);

        guiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.swixclient.gui", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, CATEGORY));
        hudKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.swixclient.hud", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_H, CATEGORY));

        // Chat command "/swix" opens the menu too (handy when there is no Right Shift, e.g. on a phone).
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("swix").executes(context -> {
                    openGuiRequested = true;
                    return 1;
                })));

        ClientTickEvents.END_CLIENT_TICK.register(this::onTick);
        HudRenderCallback.EVENT.register(this::renderHud);
    }

    public List<Module> getModules() {
        return Collections.unmodifiableList(modules);
    }

    private void register(Module module, String translationKey, int defaultKey) {
        modules.add(module);
        moduleKeys.put(module, KeyBindingHelper.registerKeyBinding(new KeyBinding(
                translationKey, InputUtil.Type.KEYSYM, defaultKey, CATEGORY)));
    }

    private void onTick(MinecraftClient client) {
        for (Map.Entry<Module, KeyBinding> entry : moduleKeys.entrySet()) {
            while (entry.getValue().wasPressed()) {
                entry.getKey().toggle();
            }
        }
        while (hudKey.wasPressed()) {
            hudVisible = !hudVisible;
        }
        while (guiKey.wasPressed()) {
            openGuiRequested = true;
        }

        if (openGuiRequested) {
            openGuiRequested = false;
            if (client.currentScreen == null || !(client.currentScreen instanceof ClickGuiScreen)) {
                client.setScreen(new ClickGuiScreen());
            }
        }

        if (client.player == null || client.world == null) return;
        for (Module module : modules) {
            if (module.isEnabled()) module.onTick();
        }
    }

    private void renderHud(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (!hudVisible || client.options.hudHidden || client.player == null) return;

        TextRenderer font = client.textRenderer;
        int y = 4;

        context.drawTextWithShadow(font, "SwixClient", 4, y, 0xFF55FFFF);
        y += 11;
        context.drawTextWithShadow(font, "FPS: " + client.getCurrentFps(), 4, y, 0xFFAAAAAA);
        y += 11;

        for (Module module : modules) {
            if (!module.isEnabled()) continue;
            context.drawTextWithShadow(font, module.getName(), 4, y, 0xFFFFFFFF);
            y += 10;
        }
    }
}
