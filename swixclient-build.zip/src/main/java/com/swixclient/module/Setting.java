package com.swixclient.module;

/** Base class for a module setting shown in the right-click panel of the menu. */
public abstract class Setting {
    private final String name;

    protected Setting(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
