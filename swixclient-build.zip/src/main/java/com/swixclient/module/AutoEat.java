package com.swixclient.module;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

/**
 * AutoEat: когда здоровье упало ниже порога, сам берёт из хотбара зачарованное золотое яблоко,
 * съедает его и возвращает прошлый слот. Если зачарованного нет, может съесть обычное золотое
 * (настройка). Не работает, пока открыт инвентарь или любой экран.
 */
public class AutoEat extends Module {
    private final NumberSetting health = add(new NumberSetting("Здоровье (HP)", 10, 2, 19, 1));
    private final BoolSetting normalApple = add(new BoolSetting("Обычное золотое яблоко", false));
    private final BoolSetting restoreSlot = add(new BoolSetting("Вернуть слот", true));

    private boolean eating;
    private boolean started;
    private int prevSlot = -1;
    private int timeout;

    public AutoEat() {
        super("AutoEat", "Авто-еда зачарованного яблока при низком HP", Category.PLAYER);
    }

    @Override
    protected void onDisable() {
        stop();
    }

    @Override
    public void onTick() {
        ClientPlayerEntity player = mc().player;
        if (player == null) return;
        if (mc().currentScreen != null) {
            stop();
            return;
        }

        if (!eating) {
            if (player.getHealth() > health.get() || player.isUsingItem()) return;
            int slot = findApple(player);
            if (slot < 0) return;
            prevSlot = player.getInventory().selectedSlot;
            player.getInventory().selectedSlot = slot;
            eating = true;
            started = false;
            timeout = 0;
        }

        if (!isApple(player.getMainHandStack())) {
            stop();
            return;
        }

        if (player.isUsingItem()) {
            started = true;
        } else if (started) {
            stop(); // доел
            return;
        }
        mc().options.useKey.setPressed(true);
        if (++timeout > 80) stop();
    }

    private int findApple(ClientPlayerEntity player) {
        for (int i = 0; i < 9; i++) {
            if (player.getInventory().getStack(i).isOf(Items.ENCHANTED_GOLDEN_APPLE)) return i;
        }
        if (normalApple.get()) {
            for (int i = 0; i < 9; i++) {
                if (player.getInventory().getStack(i).isOf(Items.GOLDEN_APPLE)) return i;
            }
        }
        return -1;
    }

    private boolean isApple(ItemStack stack) {
        return stack.isOf(Items.ENCHANTED_GOLDEN_APPLE) || (normalApple.get() && stack.isOf(Items.GOLDEN_APPLE));
    }

    private void stop() {
        if (!eating) return;
        eating = false;
        started = false;
        mc().options.useKey.setPressed(false);
        ClientPlayerEntity player = mc().player;
        if (player != null && restoreSlot.get() && prevSlot >= 0) {
            player.getInventory().selectedSlot = prevSlot;
        }
        prevSlot = -1;
    }
}
