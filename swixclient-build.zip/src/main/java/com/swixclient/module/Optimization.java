package com.swixclient.module;

import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GameOptions;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.client.option.SimpleOption;

/**
 * Optimization: временно ставит самые лёгкие настройки графики и возвращает
 * твои старые при выключении. На диск ничего не пишется (options.txt не трогаем).
 * Каждый пункт можно выключить в настройках модуля (правый клик по плитке).
 */
public class Optimization extends Module {
    private final BoolSetting particles = add(new BoolSetting("Частицы", true));
    private final BoolSetting clouds = add(new BoolSetting("Облака", true));
    private final BoolSetting fastGraphics = add(new BoolSetting("Графика", true));
    private final BoolSetting entityDistance = add(new BoolSetting("Сущности", true));
    private final BoolSetting shadows = add(new BoolSetting("Тени сущностей", true));
    private final BoolSetting bobbing = add(new BoolSetting("Тряска камеры", true));
    private final BoolSetting biomeBlend = add(new BoolSetting("Сглаж. биомов", true));
    private final BoolSetting ao = add(new BoolSetting("Освещение (AO)", true));
    private final BoolSetting cull = add(new BoolSetting("Скрывать далёкие сущности", true));
    private final NumberSetting cullDist = add(new NumberSetting("Дистанция сущностей", 24, 8, 64, 4));
    private final NumberSetting viewDistance = add(new NumberSetting("Прорисовка", 8, 2, 32, 1));
    private final NumberSetting simDistance = add(new NumberSetting("Симуляция", 5, 5, 32, 1));

    private Object oldParticles;
    private CloudRenderMode oldClouds;
    private GraphicsMode oldGraphics;
    private double oldEntityDistance;
    private static Optimization instance;
    private boolean oldAo;
    private boolean oldShadows;
    private boolean oldBobbing;
    private int oldBlend;
    private int oldView;
    private int oldSim;
    private boolean saved;
    private int tickCounter;

    public Optimization() {
        super("Optimization", "Жёстко урезает графику ради FPS", Category.UTIL);
        instance = this;
    }

    @Override
    protected void onEnable() {
        GameOptions o = mc().options;
        oldParticles = o.getParticles().getValue();
        oldClouds = o.getCloudRenderMode().getValue();
        oldGraphics = o.getGraphicsMode().getValue();
        oldEntityDistance = o.getEntityDistanceScaling().getValue();
        oldAo = o.getAo().getValue();
        oldShadows = o.getEntityShadows().getValue();
        oldBobbing = o.getBobView().getValue();
        oldBlend = o.getBiomeBlendRadius().getValue();
        oldView = o.getViewDistance().getValue();
        oldSim = o.getSimulationDistance().getValue();
        saved = true;
        tickCounter = 0;
        apply();
    }

    @Override
    protected void onDisable() {
        if (!saved) return;
        GameOptions o = mc().options;
        setParticles(o, oldParticles);
        o.getCloudRenderMode().setValue(oldClouds);
        o.getGraphicsMode().setValue(oldGraphics);
        o.getEntityDistanceScaling().setValue(oldEntityDistance);
        o.getAo().setValue(oldAo);
        o.getEntityShadows().setValue(oldShadows);
        o.getBobView().setValue(oldBobbing);
        o.getBiomeBlendRadius().setValue(oldBlend);
        o.getViewDistance().setValue(oldView);
        o.getSimulationDistance().setValue(oldSim);
        saved = false;
    }

    @Override
    public void onTick() {
        if (tickCounter++ % 20 == 0) apply();
    }

    private void apply() {
        GameOptions o = mc().options;
        setParticles(o, particles.get() ? minimal(oldParticles) : oldParticles);
        o.getCloudRenderMode().setValue(clouds.get() ? CloudRenderMode.OFF : oldClouds);
        o.getGraphicsMode().setValue(fastGraphics.get() ? GraphicsMode.FAST : oldGraphics);
        o.getEntityDistanceScaling().setValue(entityDistance.get() ? Math.min(oldEntityDistance, 0.5) : oldEntityDistance);
        o.getAo().setValue(ao.get() ? false : oldAo);
        o.getEntityShadows().setValue(shadows.get() ? false : oldShadows);
        o.getBobView().setValue(bobbing.get() ? false : oldBobbing);
        o.getBiomeBlendRadius().setValue(biomeBlend.get() ? 0 : oldBlend);
        o.getViewDistance().setValue(Math.min(oldView, viewDistance.getInt()));
        o.getSimulationDistance().setValue(Math.min(oldSim, simDistance.getInt()));
    }

    /** Частицы ставим без прямого имени класса ParticlesMode (в этой версии он лежит в другом пакете). */
    @SuppressWarnings("unchecked")
    private static void setParticles(GameOptions o, Object value) {
        ((SimpleOption<Object>) (SimpleOption<?>) o.getParticles()).setValue(value);
    }

    /** Самый лёгкий режим частиц = последняя константа enum (ALL, DECREASED, MINIMAL). */
    private static Object minimal(Object any) {
        Object[] all = ((Enum<?>) any).getDeclaringClass().getEnumConstants();
        return all[all.length - 1];
    }

    /** Called from OptimizationMixin: true = do not render this entity at all (too far, not a player). */
    public static boolean shouldCull(Entity e) {
        Optimization o = instance;
        if (o == null || !o.isEnabled() || !o.cull.get()) return false;
        if (mc().player == null || e instanceof PlayerEntity) return false;
        double d = o.cullDist.get();
        return e.squaredDistanceTo(mc().player) > d * d;
    }
}
