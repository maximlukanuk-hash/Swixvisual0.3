package com.swixclient.module;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;

/** Client-side night vision: the world is fully bright. */
public class Fullbright extends Module {
    public Fullbright() {
        super("Fullbright", "Полная яркость везде", Category.RENDER);
    }

    @Override
    public void onTick() {
        ClientPlayerEntity player = mc().player;
        if (player == null) return;

        StatusEffectInstance current = player.getStatusEffect(StatusEffects.NIGHT_VISION);
        // Refresh before the last 10 seconds so the fade-out flicker never shows.
        if (current == null || current.getDuration() < 300) {
            player.addStatusEffect(new StatusEffectInstance(
                    StatusEffects.NIGHT_VISION, 10000, 0, false, false, false));
        }
    }

    @Override
    protected void onDisable() {
        ClientPlayerEntity player = mc().player;
        if (player != null) {
            player.removeStatusEffect(StatusEffects.NIGHT_VISION);
        }
    }
}
