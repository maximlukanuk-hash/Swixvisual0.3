package com.swixclient.module;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;

/**
 * PvP-помощник (только информация на экране, ничего не делает за тебя):
 *  - здоровье и броня цели в прицеле, чтобы понимать, сколько ударов осталось;
 *  - полоска перезарядки удара: бей, когда она заполнилась (тогда урон максимальный).
 */
public class TargetHud extends Module {
    private final BoolSetting showTarget = add(new BoolSetting("Здоровье цели", true));
    private final BoolSetting showCooldown = add(new BoolSetting("Перезарядка удара", true));

    public TargetHud() {
        super("PvP HUD", "Здоровье цели и полоска перезарядки удара", Category.COMBAT);
    }

    @Override
    public void onRenderHud(DrawContext ctx) {
        ClientPlayerEntity player = mc().player;
        if (player == null || mc().options.hudHidden) return;

        int cx = ctx.getScaledWindowWidth() / 2;
        int cy = ctx.getScaledWindowHeight() / 2;
        var font = mc().textRenderer;

        if (showCooldown.get()) {
            float p = Math.min(1f, player.getAttackCooldownProgress(0f));
            int w = 40, x = cx - w / 2, y = cy + 12;
            ctx.fill(x - 1, y - 1, x + w + 1, y + 4, 0xAA000000);
            ctx.fill(x, y, x + (int) (w * p), y + 3, p >= 0.95f ? 0xFF55FF55 : 0xFFFFAA00);
        }

        if (showTarget.get()) {
            Entity looked = mc().targetedEntity;
            if (looked instanceof LivingEntity target && target.isAlive()) {
                float hp = target.getHealth();
                float maxHp = Math.max(1f, target.getMaxHealth());
                int armor = target.getArmor();
                String text = target.getName().getString() + "  " + String.format(java.util.Locale.ROOT, "%.1f", hp)
                        + "/" + (int) maxHp + "  [броня " + armor + "]";
                int w = font.getWidth(text) + 8;
                int x = cx - w / 2, y = cy + 24;
                ctx.fill(x, y, x + w, y + 20, 0xAA000000);
                ctx.drawTextWithShadow(font, text, x + 4, y + 3, 0xFFFFFFFF);
                int barW = w - 8;
                float frac = Math.min(1f, hp / maxHp);
                ctx.fill(x + 4, y + 14, x + 4 + barW, y + 17, 0xFF333333);
                ctx.fill(x + 4, y + 14, x + 4 + (int) (barW * frac), y + 17,
                        frac > 0.5f ? 0xFF55FF55 : frac > 0.25f ? 0xFFFFAA00 : 0xFFFF5555);
            }
        }
    }
}
