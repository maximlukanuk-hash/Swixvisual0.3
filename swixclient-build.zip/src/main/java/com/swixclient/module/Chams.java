package com.swixclient.module;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.client.MinecraftClient;

/**
 * Chams: the real entity model (with skin, armor, items) stays visible through walls.
 * No outline: the model itself is drawn on top of the world.
 * The actual rendering trick lives in EntityRenderDispatcherMixin (polygon offset around the entity draw).
 */
public class Chams extends Module {
    private static Chams instance;

    private final BoolSetting players = add(new BoolSetting("Игроки", true));
    private final BoolSetting mobs = add(new BoolSetting("Мобы", false));
    private final NumberSetting distance = add(new NumberSetting("Дистанция", 128, 16, 256, 8));

    public Chams() {
        super("Chams", "Модель игрока видна сквозь стены", Category.RENDER);
        instance = this;
    }

    /** Called by the render mixin for every entity: should this one be drawn through walls? */
    public static boolean shouldRender(Entity entity) {
        Chams c = instance;
        if (c == null || !c.isEnabled()) return false;

        MinecraftClient mc = mc();
        if (mc.player == null || entity == mc.player) return false;
        if (!(entity instanceof LivingEntity) || entity instanceof ArmorStandEntity) return false;

        boolean isPlayer = entity instanceof PlayerEntity;
        if (isPlayer ? !c.players.get() : !c.mobs.get()) return false;

        double max = c.distance.get();
        return entity.squaredDistanceTo(mc.player) <= max * max;
    }
}
