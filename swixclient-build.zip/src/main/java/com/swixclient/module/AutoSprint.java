package com.swixclient.module;

import net.minecraft.client.network.ClientPlayerEntity;

/**
 * Держит бег включённым, пока зажата клавиша "вперёд" (по умолчанию W) и хватает голода.
 * Это не обход правил спринта: клиент просто сам жмёт то же самое, что обычно делает
 * двойной тап W или Ctrl - серверная проверка голода и скорости работает как обычно.
 */
public class AutoSprint extends Module {
    private final BoolSetting onlyNotSneaking = add(new BoolSetting("Не красться", true));

    public AutoSprint() {
        super("AutoSprint", "Бежит вперёд без зажатого Ctrl", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        ClientPlayerEntity player = mc().player;
        if (player == null) return;

        boolean forward = mc().options.forwardKey.isPressed();
        boolean sneaking = player.isSneaking();
        boolean enoughFood = player.getHungerManager().getFoodLevel() > 6; // как и ванильный спринт

        if (forward && enoughFood && !(onlyNotSneaking.get() && sneaking)) {
            player.setSprinting(true);
        }
    }
}
