package com.swixclient.module;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

/**
 * Простая Aura для своего сервера / одиночной игры.
 * Бьёт только полностью заряженным ударом, пока открыт любой экран (инвентарь, чат, меню) - не бьёт.
 * Режимы цели: ближайшая / фокус (держится за одну цель) / только та, что в прицеле.
 * Под античит не подгонялась: на своём сервере выдай себе исключение в конфиге античита.
 */
public class KillAura extends Module {
    private final NumberSetting range = add(new NumberSetting("Дальность", 3.0, 2.0, 6.0, 0.1));
    private final BoolSetting players = add(new BoolSetting("Игроки", true));
    private final BoolSetting mobs = add(new BoolSetting("Мобы", true));
    private final BoolSetting rotate = add(new BoolSetting("Поворот к цели", true));
    private final BoolSetting throughWalls = add(new BoolSetting("Сквозь стены", false));
    private final BoolSetting focus = add(new BoolSetting("Фокус на цели", false));
    private final BoolSetting crosshairOnly = add(new BoolSetting("Только в прицеле", false));

    private LivingEntity focused;

    public KillAura() {
        super("KillAura", "Бьёт цель рядом (для своего сервера)", Category.COMBAT);
    }

    @Override
    protected void onDisable() {
        focused = null;
    }

    @Override
    public void onTick() {
        ClientPlayerEntity player = mc().player;
        if (player == null || mc().world == null || mc().interactionManager == null) return;
        if (mc().currentScreen != null || !player.isAlive()) return;
        if (player.getAttackCooldownProgress(0.5f) < 0.95f) return;

        double max = range.get();
        LivingEntity best = null;

        if (crosshairOnly.get()) {
            // цель только та, на которую смотрит прицел
            Entity looked = mc().targetedEntity;
            if (looked instanceof LivingEntity le && valid(player, le, max)) best = le;
        } else {
            // фокус: пока цель жива и в зоне - не переключаемся
            if (focus.get() && focused != null && valid(player, focused, max)) {
                best = focused;
            } else {
                double bestDist = Double.MAX_VALUE;
                for (Entity e : mc().world.getEntities()) {
                    if (!(e instanceof LivingEntity target) || !valid(player, target, max)) continue;
                    double d = player.squaredDistanceTo(target);
                    if (d < bestDist) {
                        best = target;
                        bestDist = d;
                    }
                }
            }
        }

        focused = best;
        if (best == null) return;

        if (rotate.get()) {
            Vec3d diff = best.getEyePos().subtract(player.getEyePos());
            player.setYaw((float) (Math.toDegrees(Math.atan2(diff.z, diff.x)) - 90.0));
            player.setPitch((float) -Math.toDegrees(Math.atan2(diff.y, Math.hypot(diff.x, diff.z))));
        }

        mc().interactionManager.attackEntity(player, best);
        player.swingHand(Hand.MAIN_HAND);
    }

    private boolean valid(ClientPlayerEntity player, LivingEntity target, double max) {
        if (target == player || !target.isAlive() || target instanceof ArmorStandEntity) return false;
        boolean isPlayer = target instanceof PlayerEntity p && !p.isSpectator();
        boolean isMob = target instanceof Monster;
        if (!((isPlayer && players.get()) || (isMob && mobs.get()))) return false;
        if (player.squaredDistanceTo(target) > max * max) return false;
        return throughWalls.get() || player.canSee(target);
    }
}
