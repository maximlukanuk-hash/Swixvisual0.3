package com.swixclient.module;

/** Numeric setting (a slider in the menu). */
public class NumberSetting extends Setting {
    private final double min;
    private final double max;
    private final double step;
    private double value;

    public NumberSetting(String name, double defaultValue, double min, double max, double step) {
        super(name);
        this.min = min;
        this.max = max;
        this.step = step;
        set(defaultValue);
    }

    public double get() {
        return value;
    }

    public int getInt() {
        return (int) Math.round(value);
    }

    public double getMin() {
        return min;
    }

    public double getMax() {
        return max;
    }

    public void set(double v) {
        double snapped = Math.round((v - min) / step) * step + min;
        value = Math.max(min, Math.min(max, snapped));
    }

    public String format() {
        return step >= 1 ? String.valueOf(getInt()) : String.format(java.util.Locale.ROOT, "%.1f", value);
    }
}
