package com.swixclient.module;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

/**
 * Freezes the player in place (also in the air).
 * While enabled, the position is pinned every tick, velocity is zeroed,
 * and movement packets are not sent to the server (see ClientPlayerEntityMixin).
 */
public class AirStuck extends Module {
    private static boolean active;

    private Vec3d frozenPos;
    private ClientPlayerEntity lastPlayer;

    public AirStuck() {
        super("AirStuck", "Замораживает тебя в воздухе", Category.MOVEMENT);
    }

    /** Read by the mixin to decide whether movement packets must be dropped. */
    public static boolean isActive() {
        return active;
    }

    @Override
    protected void onEnable() {
        active = true;
        ClientPlayerEntity player = mc().player;
        lastPlayer = player;
        frozenPos = player != null ? player.getPos() : null;
    }

    @Override
    protected void onDisable() {
        active = false;
        frozenPos = null;
        lastPlayer = null;
    }

    @Override
    public void onTick() {
        ClientPlayerEntity player = mc().player;
        if (player == null) return;

        // New player entity (respawn / new world): freeze at the new place.
        if (player != lastPlayer || frozenPos == null) {
            lastPlayer = player;
            frozenPos = player.getPos();
        }

        player.setVelocity(Vec3d.ZERO);
        player.setPosition(frozenPos);
        player.fallDistance = 0;
    }
}
